﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HexoAdmin
{
    public partial class CreateArticle : Form
    {
        public CreateArticle()
        {
            InitializeComponent();
            txtDate.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private void btnInsertImg_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog.Multiselect = true; // 允許多選
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                foreach (string fileName in openFileDialog.FileNames)
                {
                    PictureBox pictureBox = new PictureBox();
                    pictureBox.Image = Image.FromFile(fileName);
                    pictureBox.SizeMode = PictureBoxSizeMode.AutoSize;
                    tableLayoutPanel1.Controls.Add(pictureBox, 0, tableLayoutPanel1.RowCount);
                    tableLayoutPanel1.RowCount++;
                }
            }            
        }

        private void btnInsertVideo_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Video Files|*.mp4";
            openFileDialog.Multiselect = true; // 允許多選
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                foreach (string fileName in openFileDialog.FileNames)
                {
                    // 創建一個 PictureBox 來顯示視頻的預覽圖
                    PictureBox pictureBox = new PictureBox();
                    pictureBox.Image = GetVideoThumbnail(fileName);
                    pictureBox.SizeMode = PictureBoxSizeMode.AutoSize;
                    tableLayoutPanel1.Controls.Add(pictureBox, 0, tableLayoutPanel1.RowCount);
                    tableLayoutPanel1.RowCount++;
                }
            }
        }

        private Image GetVideoThumbnail(string videoFilePath)
        {
            // 這裡你可以使用第三方庫來獲取視頻的預覽圖，例如 FFmpeg 或 DirectShow
            // 這裡只是一個簡單的示例，返回一個預設圖像
            return Image.FromFile("default_thumbnail.png");
        }

        private void btnCreateText_Click(object sender, EventArgs e)
        {
            TextBox textArea = new TextBox();
            textArea.Multiline = true;
            textArea.Dock = DockStyle.Top;
            textArea.Height = 250;
            tableLayoutPanel1.Controls.Add(textArea, 0 ,tableLayoutPanel1.RowCount);
            tableLayoutPanel1.RowCount++;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string md_FileName = ConfigurationManager.AppSettings["md_path"] + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".md";


            StringBuilder contents = new StringBuilder();

            contents.AppendLine("---");
            contents.AppendLine("title: " + txtTitle.Text.Trim() + " ");
            contents.AppendLine("date: " + txtDate.Text.Trim() + " ");
            contents.AppendLine("top:");
            contents.AppendLine("tags:" );
            contents.AppendLine("- [" + txtTag.Text.Trim() + "]");
            contents.AppendLine("categories:");
            contents.AppendLine("- [" + txtCategories.Text.Trim() + "]");
            contents.AppendLine("---------------------------------------------");            
            int i = 1;
            int j = 1;
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                if (control is TextBox textBox)
                {
                    string[] lines = textBox.Text.Split(new[] { "\r\n" }, StringSplitOptions.None);

                    foreach (string str in lines)
                    {
                        if (j == 1)
                        {
                            contents.AppendLine("# **<a href=\"#\" style=\"color: #ca3333;\">" + str + "</a>**");
                        }
                        else
                        {
                            if (str.ToLower().Contains("http"))
                            {
                                string url = str.Substring(str.IndexOf("http"));
                                string tmptile = str.Substring(0, str.IndexOf("http"));
                                contents.AppendLine("");
                                contents.AppendLine($"{tmptile} [{url}]({url})");
                            }
                            else
                            {
                                contents.AppendLine($"{str}");
                            }
                        }
                        j++;
                    }
                }
                else if (control is PictureBox pictureBox)
                {
                    string img_file = ConfigurationManager.AppSettings["img_path"] + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".jpg";
                    pictureBox.Image.Save(img_file, ImageFormat.Jpeg);
                    contents.AppendLine("");
                    contents.AppendLine("![images](../images/" + Path.GetFileName(img_file) + ")");
                }

                if(i==4)
                {
                    contents.AppendLine("<!--more-->");
                }

                i++;
            }
            File.WriteAllText(md_FileName, contents.ToString());
            MessageBox.Show("Contents saved successfully.", "Save File");

        }
    }
}
