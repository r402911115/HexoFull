﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HexoAdmin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCreateArticle_Click(object sender, EventArgs e)
        {
            CreateArticle obj = new CreateArticle();
            obj.FormClosed += new FormClosedEventHandler(obj_FormClosed);
            obj.Show();
            this.Hide();
        }
        void obj_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Show();//子視窗關閉時,父視窗再顯示出來
        }        

        private void BtnDeleteArticle_Click(object sender, EventArgs e)
        {
            DeleteArticle obj = new DeleteArticle();
            obj.FormClosed += new FormClosedEventHandler(obj_FormClosed);
            obj.Show();
            this.Hide();
        }

        private void btnUploadArticle_Click(object sender, EventArgs e)
        {
            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = "-Command \"hexo clean; hexo g; hexo d\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(startInfo))
                {
                    using (StreamReader reader = process.StandardOutput)
                    {
                        string result = reader.ReadToEnd();
                        MessageBox.Show(result, "PowerShell Output");
                    }

                    using (StreamReader errorReader = process.StandardError)
                    {
                        string error = errorReader.ReadToEnd();
                        if (!string.IsNullOrEmpty(error))
                        {
                            MessageBox.Show("PowerShell Error: " + error, "Error");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing PowerShell commands: " + ex.Message, "Error");
            }
        }

        private void btnTopArticle_Click(object sender, EventArgs e)
        {
            TopArticle obj = new TopArticle();
            obj.FormClosed += new FormClosedEventHandler(obj_FormClosed);
            obj.Show();
            this.Hide();
        }

        private void btnInitWeb_Click(object sender, EventArgs e)
        {
            try
            {
                // 獲取應用程序的 Bin 目錄路徑
                string binDirectory = AppDomain.CurrentDomain.BaseDirectory;
                string hexoBatPath = Path.Combine(binDirectory, "hexoServe.bat");

                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = hexoBatPath,
                    Arguments = "",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(startInfo))
                {
                    using (StreamReader reader = process.StandardOutput)
                    {
                        string result = reader.ReadToEnd();
                        MessageBox.Show(result, "Batch File Output");
                    }

                    using (StreamReader errorReader = process.StandardError)
                    {
                        string error = errorReader.ReadToEnd();
                        if (!string.IsNullOrEmpty(error))
                        {
                            MessageBox.Show("Batch File Error: " + error, "Error");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing batch file: " + ex.Message, "Error");
            }
        }
    }
}
