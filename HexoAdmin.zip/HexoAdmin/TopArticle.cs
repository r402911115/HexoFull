﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HexoAdmin
{
    public partial class TopArticle : Form
    {
        List<top_file_info> file_info_list = new List<top_file_info>();
        public TopArticle()
        {
            InitializeComponent();
            getFiles();
        }

        public void getFiles()
        {
            
            listView1.Items.Clear();
            file_info_list = new List<top_file_info>();
            string File_path = ConfigurationManager.AppSettings["md_path"];

            string[] file_list = Directory.GetFiles(File_path, "*.md");

            foreach (string file in file_list)
            {
                top_file_info tmpfile = GetMarkdownTitle(file);
                file_info_list.Add(tmpfile);
            }           

            listView1.Columns.Add("Seq", 60, HorizontalAlignment.Left);
            listView1.Columns.Add("檔名", 500, HorizontalAlignment.Left);
            listView1.BeginUpdate();

            foreach (top_file_info data in file_info_list.OrderBy(x => string.IsNullOrEmpty(x.seq.Trim())).ThenByDescending(x => x.seq).ToList())
            {
                ListViewItem lv = new ListViewItem();

                lv.Text = data.seq;
                lv.SubItems.Add(data.file_tilte);
                listView1.Items.Add(lv);
            }

            listView1.EndUpdate();
        }




        private top_file_info GetMarkdownTitle(string filePath)
        {
            top_file_info tmp_info = new top_file_info();

            tmp_info.file_path = filePath;
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.StartsWith("title"))
                    {
                        tmp_info.file_tilte = line.Replace("title:", "");
                    }

                    if (line.StartsWith("top"))
                    {
                        tmp_info.seq = line.Replace("top:", "");
                    }
                }
            }
            return tmp_info;
        }

        class top_file_info
        {
            public string file_tilte { get; set; }
            public string file_path { get; set; }

            public string seq { get; set; }
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            //if (string.IsNullOrEmpty(txtSeq.Text))
            //{
            //    MessageBox.Show("請輸入要修改的排序");
            //    return;
            //}

            for (int i = 0; i < listView1.CheckedItems.Count; i++)
            {
                String file = listView1.CheckedItems[i].SubItems[1].Text;
                string set_path = file_info_list.Where(x => x.file_tilte.Equals(file)).Select(x => x.file_path).FirstOrDefault();

                // 讀取檔案內容到記憶體中
                List<string> lines = new List<string>();
                using (StreamReader reader = new StreamReader(set_path))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        lines.Add(line);
                    }
                }

                for (int j = 0; j < lines.Count; j++)
                {
                    if (lines[j].StartsWith("top"))
                    {
                        if (!string.IsNullOrEmpty(txtSeq.Text))
                        {
                            lines[j] = "top: " + txtSeq.Text.Trim();
                        }
                        else
                        {
                            lines[j] = "";
                        }
                    }
                }

                // 寫入修改後的內容到檔案
                using (StreamWriter writer = new StreamWriter(set_path))
                {
                    foreach (string line in lines)
                    {
                        writer.WriteLine(line);
                    }
                }                
            }

            getFiles();
        }
    }   
}
