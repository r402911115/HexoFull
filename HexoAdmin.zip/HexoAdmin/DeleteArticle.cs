﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HexoAdmin
{

    public partial class DeleteArticle : Form
    {
        List<del_file_info> file_info_list = new List<del_file_info>();

        public DeleteArticle()
        {
            InitializeComponent();
            getFiles();
        }

        public void getFiles()
        {
            listView1.Items.Clear();
            file_info_list = new List<del_file_info>();
            string File_path = ConfigurationManager.AppSettings["md_path"];

            string[] file_list = Directory.GetFiles(File_path, "*.md");

            foreach (string file in file_list)
            {
                del_file_info tmpfile = new del_file_info();
                string title = GetMarkdownTitle(file);
                if (!string.IsNullOrEmpty(title))
                {
                    tmpfile.file_tilte = title;
                    tmpfile.file_path = file;
                    file_info_list.Add(tmpfile);
                }
            }


            listView1.Columns.Add("序號", 60, HorizontalAlignment.Left);
            listView1.Columns.Add("檔名", 500, HorizontalAlignment.Left);
            listView1.BeginUpdate();

            int i = 1;
            foreach (del_file_info data in file_info_list)
            {
                ListViewItem lv = new ListViewItem();

                lv.Text = i + ".";
                lv.SubItems.Add(data.file_tilte);
                listView1.Items.Add(lv);
                i++;
            }

            listView1.EndUpdate();
        }

        private string GetMarkdownTitle(string filePath)
        {
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.StartsWith("title"))
                    {
                        return line.Replace("title:", "");
                    }
                }
            }
            return null;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            List<string> delete_list = new List<string>();
            StringBuilder deleteAlert = new StringBuilder();
            deleteAlert.AppendLine("確定刪除?，下列項目 : ");
            for (int i = 0; i < listView1.CheckedItems.Count; i++)
            {
                String tmp = listView1.CheckedItems[i].SubItems[1].Text;

                delete_list.Add(tmp);
                deleteAlert.AppendLine(tmp);
            }

            var result = MessageBox.Show(deleteAlert.ToString(), "視窗關閉", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                foreach (string deletestr in delete_list)
                {
                    string delete_path = file_info_list.Where(x => x.file_tilte.Equals(deletestr)).Select(x => x.file_path).FirstOrDefault();
                    File.Delete(delete_path);
                }
            }

            getFiles();
        }

        class del_file_info
        {
            public string file_tilte { get; set; }
            public string file_path { get; set; }
        }
    }
}
