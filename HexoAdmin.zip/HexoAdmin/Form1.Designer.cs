﻿namespace HexoAdmin
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnCreateArticle = new System.Windows.Forms.Button();
            this.BtnDeleteArticle = new System.Windows.Forms.Button();
            this.btnUploadArticle = new System.Windows.Forms.Button();
            this.btnTopArticle = new System.Windows.Forms.Button();
            this.btnInitWeb = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnCreateArticle
            // 
            this.BtnCreateArticle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.BtnCreateArticle.Location = new System.Drawing.Point(400, 232);
            this.BtnCreateArticle.Name = "BtnCreateArticle";
            this.BtnCreateArticle.Size = new System.Drawing.Size(388, 194);
            this.BtnCreateArticle.TabIndex = 0;
            this.BtnCreateArticle.Text = "新增文章";
            this.BtnCreateArticle.UseVisualStyleBackColor = true;
            this.BtnCreateArticle.Click += new System.EventHandler(this.BtnCreateArticle_Click);
            // 
            // BtnDeleteArticle
            // 
            this.BtnDeleteArticle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.BtnDeleteArticle.Location = new System.Drawing.Point(6, 12);
            this.BtnDeleteArticle.Name = "BtnDeleteArticle";
            this.BtnDeleteArticle.Size = new System.Drawing.Size(388, 214);
            this.BtnDeleteArticle.TabIndex = 1;
            this.BtnDeleteArticle.Text = "刪除文章";
            this.BtnDeleteArticle.UseVisualStyleBackColor = true;
            this.BtnDeleteArticle.Click += new System.EventHandler(this.BtnDeleteArticle_Click);
            // 
            // btnUploadArticle
            // 
            this.btnUploadArticle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnUploadArticle.Location = new System.Drawing.Point(12, 441);
            this.btnUploadArticle.Name = "btnUploadArticle";
            this.btnUploadArticle.Size = new System.Drawing.Size(776, 194);
            this.btnUploadArticle.TabIndex = 2;
            this.btnUploadArticle.Text = "上傳文章";
            this.btnUploadArticle.UseVisualStyleBackColor = true;
            this.btnUploadArticle.Click += new System.EventHandler(this.btnUploadArticle_Click);
            // 
            // btnTopArticle
            // 
            this.btnTopArticle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTopArticle.Location = new System.Drawing.Point(400, 12);
            this.btnTopArticle.Name = "btnTopArticle";
            this.btnTopArticle.Size = new System.Drawing.Size(388, 214);
            this.btnTopArticle.TabIndex = 3;
            this.btnTopArticle.Text = "置頂文章";
            this.btnTopArticle.UseVisualStyleBackColor = true;
            this.btnTopArticle.Click += new System.EventHandler(this.btnTopArticle_Click);
            // 
            // btnInitWeb
            // 
            this.btnInitWeb.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnInitWeb.Location = new System.Drawing.Point(6, 232);
            this.btnInitWeb.Name = "btnInitWeb";
            this.btnInitWeb.Size = new System.Drawing.Size(388, 194);
            this.btnInitWeb.TabIndex = 4;
            this.btnInitWeb.Text = "預覽網站";
            this.btnInitWeb.UseVisualStyleBackColor = true;
            this.btnInitWeb.Click += new System.EventHandler(this.btnInitWeb_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 647);
            this.Controls.Add(this.btnInitWeb);
            this.Controls.Add(this.btnTopArticle);
            this.Controls.Add(this.btnUploadArticle);
            this.Controls.Add(this.BtnDeleteArticle);
            this.Controls.Add(this.BtnCreateArticle);
            this.Name = "Form1";
            this.Text = "王李文章管理系統";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnCreateArticle;
        private System.Windows.Forms.Button BtnDeleteArticle;
        private System.Windows.Forms.Button btnUploadArticle;
        private System.Windows.Forms.Button btnTopArticle;
        private System.Windows.Forms.Button btnInitWeb;
    }
}

